Sys.setenv("R_TESTS" = "")
library(testthat)
library(discreteQ)

test_check("discreteQ")
